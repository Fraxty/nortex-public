# NORTEX

### Official Software Project
**NORTEX** is an independent software project focused on its own programming language, compiler technology and integrated development environment.

## NORTEX Code
NORTEX Code is an integrated development environment designed for developing software with the NORTEX programming language.

### Current Release
**NORTEX Code – Public Preview 0.1.0**

- Early public testing version
- Free public download (MIT License)
- Free public download
- Feedback and bug reports welcome

## Project Components

- **NORTEX Language** – Independent programming language
- **NORTEX Compiler** – Compiler and language processing
- **NORTEX Code** – Integrated development environment
- **NORTEX Tools** – Additional development utilities

## Downloads
Download the latest public preview from the [Releases](../../releases) section.

| File | Description |
|---|---|
| `NORTEX-Setup-x64.exe` | Windows installer (Start menu entry, optional desktop shortcut, uninstaller; per-user, no administrator rights by default) |
| `NORTEX-Portable-x64.zip` | Portable version: unzip and run `bin\nortex-code.exe`; no installation |
| `SHA256SUMS.txt` | SHA-256 checksums of the release files |

**Platform:** Windows 11 x64. Windows 10 has not been tested and is not supported.
**Not code-signed:** The files are currently *not* digitally signed, so Windows SmartScreen may show a warning. Verify the download with the checksums:

```powershell
Get-FileHash .\NORTEX-Setup-x64.exe -Algorithm SHA256
```

See [INSTALLATION.md](INSTALLATION.md) for details.

## Feedback and Bug Reports
Found a problem or have a suggestion? Please use the GitHub Issues section to submit bug reports and feature requests.

**Security vulnerabilities must not be reported in public issues.** See [SECURITY.md](SECURITY.md).

## Project Status
NORTEX is currently under active development. Features, interfaces and language specifications may change between releases. There is no debugger yet (the compiler does not produce debug information).

## Licensing
NORTEX is released under the MIT License (see [LICENSE](LICENSE)). Public preview releases are provided "as is" for testing and evaluation.

Third-party components are listed in [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).

## Privacy
NORTEX Code contains no telemetry and sends no data automatically. See [PRIVACY.md](PRIVACY.md).

## Disclaimer
This is a pre-release version. It is provided for testing and evaluation purposes and is not intended for production use.

---

**NORTEX – Independent Software Project**
